; Hook NSIS untuk installer Shinon Dock.
; Menambahkan pintasan "Kredit" di Start Menu yang membuka CREDITS.txt di Notepad.

!macro NSIS_HOOK_POSTINSTALL
  CreateDirectory "$SMPROGRAMS\Shinon Dock"
  CreateShortCut "$SMPROGRAMS\Shinon Dock\Kredit.lnk" "$WINDIR\notepad.exe" '"$INSTDIR\CREDITS.txt"'
!macroend

!macro NSIS_HOOK_POSTUNINSTALL
  Delete "$SMPROGRAMS\Shinon Dock\Kredit.lnk"
!macroend
