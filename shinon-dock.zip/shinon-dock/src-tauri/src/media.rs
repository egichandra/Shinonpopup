#![cfg_attr(not(windows), allow(dead_code))]
//! Music Controller via Windows SMTC
//! (GlobalSystemMediaTransportControlsSessionManager).
//!
//! Desain hemat resource:
//! - TIDAK ada polling. Satu worker thread tidur di `recv()` dan hanya bangun
//!   saat Windows mengirim event (lagu ganti, play/pause, timeline berubah)
//!   atau saat UI mengirim perintah.
//! - Posisi lagu tidak di-stream; frontend menginterpolasi dari
//!   `positionMs + (now - updatedAtMs)`.
//! - Cover art (base64) dikirim lewat event terpisah, hanya saat lagu berganti.

use std::sync::mpsc::{channel, Sender};
use std::sync::Mutex;

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Manager, State};

#[derive(Debug, Clone, Default, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MediaState {
    pub has_session: bool,
    pub app_id: String,
    pub title: String,
    pub artist: String,
    pub album: String,
    pub track_key: String,
    pub is_playing: bool,
    pub position_ms: u64,
    pub duration_ms: u64,
    /// Unix epoch (ms) saat `position_ms` dicatat oleh aplikasi pemutar.
    pub updated_at_ms: u64,
    pub can_prev: bool,
    pub can_next: bool,
    pub can_toggle: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Artwork {
    pub track_key: String,
    pub data_url: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum MediaCommand {
    TogglePlay,
    Next,
    Previous,
    Seek {
        #[serde(rename = "positionMs")]
        position_ms: u64,
    },
    /// Minta snapshot ulang (dipakai UI saat baru dimuat).
    Refresh,
}

#[allow(dead_code)]
enum Msg {
    Refresh,
    Rebind,
    Cmd(MediaCommand),
}

pub struct MediaBridge(Mutex<Sender<Msg>>);

#[tauri::command]
pub fn media_command(bridge: State<MediaBridge>, cmd: MediaCommand) {
    if let Ok(tx) = bridge.0.lock() {
        let _ = tx.send(Msg::Cmd(cmd));
    }
}

pub fn start(app: AppHandle) {
    let (tx, rx) = channel::<Msg>();
    app.manage(MediaBridge(Mutex::new(tx.clone())));

    std::thread::Builder::new()
        .name("smtc-worker".into())
        .spawn(move || {
            #[cfg(windows)]
            if let Err(e) = imp::run(app, tx, rx) {
                eprintln!("[media] SMTC worker berhenti: {e:?}");
            }
            #[cfg(not(windows))]
            {
                let _ = (app, tx);
                while rx.recv().is_ok() {}
            }
        })
        .expect("gagal membuat thread smtc-worker");
}

#[cfg(windows)]
mod imp {
    use super::*;
    use base64::{engine::general_purpose::STANDARD as B64, Engine};
    use std::sync::mpsc::Receiver;
    use tauri::Emitter;
    use windows::core::Result;
    use windows::Foundation::{EventRegistrationToken, TypedEventHandler};
    use windows::Media::Control::{
        GlobalSystemMediaTransportControlsSession as Session,
        GlobalSystemMediaTransportControlsSessionManager as Manager,
        GlobalSystemMediaTransportControlsSessionMediaProperties as Props,
        GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status,
    };
    use windows::Storage::Streams::DataReader;
    use windows::Win32::System::WinRT::{RoInitialize, RO_INIT_MULTITHREADED};

    /// 100-ns ticks antara 1601-01-01 (FILETIME) dan 1970-01-01 (Unix).
    const EPOCH_DIFF_TICKS: i64 = 116_444_736_000_000_000;
    const MAX_ARTWORK_BYTES: u32 = 4 * 1024 * 1024;

    struct Bound {
        session: Session,
        t_props: EventRegistrationToken,
        t_play: EventRegistrationToken,
        t_time: EventRegistrationToken,
    }

    impl Bound {
        fn attach(session: Session, tx: &Sender<Msg>) -> Result<Self> {
            let (a, b, c) = (tx.clone(), tx.clone(), tx.clone());
            let t_props = session.MediaPropertiesChanged(&TypedEventHandler::new(move |_, _| {
                let _ = a.send(Msg::Refresh);
                Ok(())
            }))?;
            let t_play = session.PlaybackInfoChanged(&TypedEventHandler::new(move |_, _| {
                let _ = b.send(Msg::Refresh);
                Ok(())
            }))?;
            let t_time = session.TimelinePropertiesChanged(&TypedEventHandler::new(move |_, _| {
                let _ = c.send(Msg::Refresh);
                Ok(())
            }))?;
            Ok(Self { session, t_props, t_play, t_time })
        }

        fn detach(self) {
            let _ = self.session.RemoveMediaPropertiesChanged(self.t_props);
            let _ = self.session.RemovePlaybackInfoChanged(self.t_play);
            let _ = self.session.RemoveTimelinePropertiesChanged(self.t_time);
        }
    }

    pub fn run(app: AppHandle, tx: Sender<Msg>, rx: Receiver<Msg>) -> Result<()> {
        unsafe {
            let _ = RoInitialize(RO_INIT_MULTITHREADED);
        }
        let manager = Manager::RequestAsync()?.get()?;

        {
            let t1 = tx.clone();
            manager.CurrentSessionChanged(&TypedEventHandler::new(move |_, _| {
                let _ = t1.send(Msg::Rebind);
                Ok(())
            }))?;
            let t2 = tx.clone();
            manager.SessionsChanged(&TypedEventHandler::new(move |_, _| {
                let _ = t2.send(Msg::Rebind);
                Ok(())
            }))?;
        }

        let mut bound: Option<Bound> = None;
        let mut sent_art_key = String::new();
        let _ = tx.send(Msg::Rebind);

        while let Ok(first) = rx.recv() {
            // Gabungkan event yang datang beruntun (Spotify bisa kirim 3–4
            // event sekaligus saat ganti lagu) → cukup satu kali baca state.
            let mut rebind = false;
            let mut refresh = false;
            let mut force_art = false;
            let mut cmds = Vec::new();
            for msg in std::iter::once(first).chain(rx.try_iter()) {
                match msg {
                    Msg::Rebind => rebind = true,
                    Msg::Refresh => refresh = true,
                    Msg::Cmd(MediaCommand::Refresh) => {
                        refresh = true;
                        force_art = true;
                    }
                    Msg::Cmd(c) => cmds.push(c),
                }
            }

            if rebind {
                if let Some(b) = bound.take() {
                    b.detach();
                }
                bound = manager
                    .GetCurrentSession()
                    .ok()
                    .and_then(|s| Bound::attach(s, &tx).ok());
                refresh = true;
            }

            if let Some(b) = &bound {
                for c in cmds {
                    if let Err(e) = execute(&b.session, c) {
                        eprintln!("[media] perintah gagal: {e:?}");
                    }
                }
            }

            if !refresh {
                continue;
            }

            match bound.as_ref().map(|b| read_state(&b.session)) {
                Some(Ok((state, props))) => {
                    if force_art || state.track_key != sent_art_key {
                        let data_url = read_artwork(&props);
                        // Beberapa app (mis. Spotify) mengirim thumbnail
                        // sesaat SETELAH judul → coba lagi di event berikutnya.
                        if data_url.is_some() {
                            sent_art_key = state.track_key.clone();
                        }
                        let _ = app.emit("media://update", &state);
                        let _ = app.emit(
                            "media://artwork",
                            Artwork { track_key: state.track_key.clone(), data_url },
                        );
                    } else {
                        let _ = app.emit("media://update", &state);
                    }
                }
                _ => {
                    sent_art_key.clear();
                    let _ = app.emit("media://update", MediaState::default());
                }
            }
        }
        Ok(())
    }

    fn execute(s: &Session, cmd: MediaCommand) -> Result<()> {
        match cmd {
            MediaCommand::TogglePlay => {
                s.TryTogglePlayPauseAsync()?.get()?;
            }
            MediaCommand::Next => {
                s.TrySkipNextAsync()?.get()?;
            }
            MediaCommand::Previous => {
                s.TrySkipPreviousAsync()?.get()?;
            }
            MediaCommand::Seek { position_ms } => {
                s.TryChangePlaybackPositionAsync(position_ms as i64 * 10_000)?.get()?;
            }
            MediaCommand::Refresh => {}
        }
        Ok(())
    }

    fn read_state(s: &Session) -> Result<(MediaState, Props)> {
        let props = s.TryGetMediaPropertiesAsync()?.get()?;
        let title = props.Title()?.to_string_lossy();
        let artist = props.Artist()?.to_string_lossy();
        let album = props.AlbumTitle()?.to_string_lossy();

        let pb = s.GetPlaybackInfo()?;
        let is_playing = pb.PlaybackStatus()? == Status::Playing;
        let controls = pb.Controls()?;

        let tl = s.GetTimelineProperties()?;
        let start = tl.StartTime()?.Duration;
        let end = tl.EndTime()?.Duration;
        let pos = tl.Position()?.Duration;
        let updated = tl.LastUpdatedTime()?.UniversalTime;

        let state = MediaState {
            has_session: true,
            app_id: s.SourceAppUserModelId()?.to_string_lossy(),
            track_key: format!("{title}\u{1f}{artist}\u{1f}{album}"),
            title,
            artist,
            album,
            is_playing,
            position_ms: ((pos - start).max(0) / 10_000) as u64,
            duration_ms: ((end - start).max(0) / 10_000) as u64,
            updated_at_ms: ((updated - EPOCH_DIFF_TICKS).max(0) / 10_000) as u64,
            can_prev: controls.IsPreviousEnabled()?,
            can_next: controls.IsNextEnabled()?,
            can_toggle: controls.IsPlayPauseToggleEnabled()?,
        };
        Ok((state, props))
    }

    fn read_artwork(props: &Props) -> Option<String> {
        let stream = props.Thumbnail().ok()?.OpenReadAsync().ok()?.get().ok()?;
        let size = stream.Size().ok()? as u32;
        if size == 0 || size > MAX_ARTWORK_BYTES {
            return None;
        }
        let mime = stream
            .ContentType()
            .ok()
            .map(|h| h.to_string_lossy())
            .filter(|m| m.starts_with("image/"))
            .unwrap_or_else(|| "image/png".into());

        let reader = DataReader::CreateDataReader(&stream.GetInputStreamAt(0).ok()?).ok()?;
        reader.LoadAsync(size).ok()?.get().ok()?;
        let mut buf = vec![0u8; size as usize];
        reader.ReadBytes(&mut buf).ok()?;
        Some(format!("data:{mime};base64,{}", B64.encode(buf)))
    }
}
