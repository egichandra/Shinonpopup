//! Konfigurasi window dock — gaya NOTCH di tepi atas layar:
//! - diletakkan di tengah-atas work area, menempel ke tepi atas
//! - WS_EX_NOACTIVATE + WS_EX_TOOLWINDOW → klik dock tidak mencuri fokus,
//!   tidak muncul di Alt+Tab
//! - Window region dipotong berbentuk notch: sudut atas lurus, sudut bawah
//!   membulat, plus dua "telinga" cekung di kiri-kanan atas (seperti poni HP).
//!   Area di luar notch otomatis click-through.
//! - Ghost mode: seluruh window click-through, kursor dipantau dari Rust;
//!   menyentuh tepi atas layar memunculkan dock.

use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

use tauri::{AppHandle, Emitter, Manager, PhysicalPosition, State, WebviewWindow};

#[derive(Default)]
pub struct DockState {
    pub ghost: AtomicBool,
}

pub fn configure(win: &WebviewWindow) -> tauri::Result<()> {
    place_at_top(win)?;
    #[cfg(windows)]
    win32::apply_tool_styles(win);
    Ok(())
}

/// Tengah-atas work area monitor utama (menempel ke tepi atas layar).
pub fn place_at_top(win: &WebviewWindow) -> tauri::Result<()> {
    let size = win.outer_size()?;
    let (left, top, right, _bottom) = work_area(win);
    let x = left + ((right - left) - size.width as i32) / 2;
    win.set_position(PhysicalPosition::new(x, top))?;
    Ok(())
}

#[cfg(windows)]
fn work_area(_win: &WebviewWindow) -> (i32, i32, i32, i32) {
    win32::work_area()
}

#[cfg(not(windows))]
fn work_area(win: &WebviewWindow) -> (i32, i32, i32, i32) {
    match win.current_monitor() {
        Ok(Some(m)) => {
            let p = m.position();
            let s = m.size();
            (p.x, p.y, p.x + s.width as i32, p.y + s.height as i32 - 48)
        }
        _ => (0, 0, 1920, 1032),
    }
}

/// Frontend melaporkan kotak notch (CSS px, relatif ke window): posisi,
/// ukuran, radius sudut bawah `r`, ukuran telinga cekung `ear`, dan kotak
/// maskot Shinon yang menggantung di bawah notch (`mx,my,mw,mh`; 0 = tidak ada).
#[tauri::command]
#[allow(clippy::too_many_arguments)]
pub fn set_pill_rect(
    window: WebviewWindow,
    x: f64,
    y: f64,
    w: f64,
    h: f64,
    r: f64,
    ear: f64,
    mx: Option<f64>,
    my: Option<f64>,
    mw: Option<f64>,
    mh: Option<f64>,
) {
    let s = window.scale_factor().unwrap_or(1.0);
    let px = |v: f64| (v * s).round() as i32;
    let (mx, my, mw, mh) = (mx.unwrap_or(0.0), my.unwrap_or(0.0), mw.unwrap_or(0.0), mh.unwrap_or(0.0));
    let mascot = (mw > 0.0 && mh > 0.0).then(|| (px(mx), px(my), px(mx + mw), px(my + mh)));
    #[cfg(windows)]
    win32::set_notch_region(&window, px(x), px(y), px(x + w), px(y + h), px(r), px(ear), mascot);
    #[cfg(not(windows))]
    let _ = (px(x), px(y), px(w), px(h), px(r), px(ear), mascot);
}

/// Ghost = notch menyusut jadi garis tipis di tepi atas, 100% tembus klik.
#[tauri::command]
pub fn set_ghost(window: WebviewWindow, state: State<DockState>, ghost: bool) {
    state.ghost.store(ghost, Ordering::Relaxed);
    let _ = window.set_ignore_cursor_events(ghost);
}

/// Memantau kursor HANYA saat ghost mode (window sedang tembus klik).
/// Biaya: satu GetCursorPos per 120 ms — praktis 0% CPU.
pub fn start_hover_watch(app: AppHandle) {
    std::thread::spawn(move || {
        let mut dwell = 0u8;
        loop {
            let ghost = app.state::<DockState>().ghost.load(Ordering::Relaxed);
            std::thread::sleep(Duration::from_millis(if ghost { 120 } else { 500 }));
            if !ghost {
                dwell = 0;
                continue;
            }
            let Some(win) = app.get_webview_window("dock") else { continue };
            let (Ok(pos), Ok(size)) = (win.outer_position(), win.outer_size()) else { continue };
            let s = win.scale_factor().unwrap_or(1.0);

            // Zona pemicu: strip 24px di tepi ATAS layar, selebar setengah window.
            let zone_l = pos.x + size.width as i32 / 4;
            let zone_r = pos.x + (size.width as i32 * 3) / 4;
            let zone_t = pos.y;
            let zone_b = pos.y + (24.0 * s) as i32;

            let inside = cursor_pos()
                .map(|(cx, cy)| cx >= zone_l && cx <= zone_r && cy >= zone_t && cy <= zone_b)
                .unwrap_or(false);

            // ~240 ms diam di zona → muncul (hindari terpicu saat kursor menuju
            // tab browser / title bar).
            dwell = if inside { dwell.saturating_add(1) } else { 0 };
            if dwell == 2 {
                let _ = app.emit("dock://hover", true);
            }
        }
    });
}

#[cfg(windows)]
fn cursor_pos() -> Option<(i32, i32)> {
    win32::cursor_pos()
}

#[cfg(not(windows))]
fn cursor_pos() -> Option<(i32, i32)> {
    None
}

#[cfg(windows)]
mod win32 {
    use tauri::WebviewWindow;
    use windows::Win32::Foundation::{BOOL, HWND, POINT, RECT};
    use windows::Win32::Graphics::Gdi::{
        CombineRgn, CreateEllipticRgn, CreateRectRgn, CreateRoundRectRgn, DeleteObject, SetWindowRgn,
        HGDIOBJ, HRGN, RGN_DIFF, RGN_OR,
    };
    use windows::Win32::UI::WindowsAndMessaging::{
        GetCursorPos, GetWindowLongPtrW, SetWindowLongPtrW, SystemParametersInfoW, GWL_EXSTYLE,
        SPI_GETWORKAREA, SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS, WS_EX_NOACTIVATE, WS_EX_TOOLWINDOW,
    };

    fn hwnd(win: &WebviewWindow) -> Option<HWND> {
        // Tauri memakai versi crate `windows` yang berbeda → konversi lewat raw pointer.
        win.hwnd().ok().map(|h| HWND(h.0 as _))
    }

    pub fn apply_tool_styles(win: &WebviewWindow) {
        let Some(h) = hwnd(win) else { return };
        unsafe {
            let ex = GetWindowLongPtrW(h, GWL_EXSTYLE);
            SetWindowLongPtrW(
                h,
                GWL_EXSTYLE,
                ex | WS_EX_NOACTIVATE.0 as isize | WS_EX_TOOLWINDOW.0 as isize,
            );
        }
    }

    unsafe fn free(rgn: HRGN) {
        let _ = DeleteObject(HGDIOBJ(rgn.0));
    }

    /// Bentuk notch:
    ///   ▄▄█████████████▄▄   ← telinga cekung kiri & kanan (lebar = ear)
    ///     █████████████
    ///     ╰███████████╯     ← sudut bawah membulat (radius r)
    #[allow(clippy::too_many_arguments)]
    pub fn set_notch_region(
        win: &WebviewWindow,
        l: i32,
        t: i32,
        r: i32,
        b: i32,
        radius: i32,
        ear: i32,
        mascot: Option<(i32, i32, i32, i32)>,
    ) {
        let Some(h) = hwnd(win) else { return };
        unsafe {
            // Trik: round-rect yang sudut atasnya berada di LUAR window → sudut atas lurus.
            let body = CreateRoundRectRgn(l, t - radius * 2, r + 1, b + 1, radius * 2, radius * 2);

            if ear > 0 {
                // Telinga kiri: kotak (l-ear..l, t..t+ear) dikurangi lingkaran berpusat (l-ear, t+ear).
                let left = CreateRectRgn(l - ear, t, l, t + ear);
                let lcut = CreateEllipticRgn(l - 2 * ear, t, l, t + 2 * ear);
                CombineRgn(left, left, lcut, RGN_DIFF);
                CombineRgn(body, body, left, RGN_OR);
                free(left);
                free(lcut);

                // Telinga kanan: cermin dari kiri.
                let right = CreateRectRgn(r + 1, t, r + 1 + ear, t + ear);
                let rcut = CreateEllipticRgn(r + 1, t, r + 1 + 2 * ear, t + 2 * ear);
                CombineRgn(right, right, rcut, RGN_DIFF);
                CombineRgn(body, body, right, RGN_OR);
                free(right);
                free(rcut);
            }

            // Area maskot yang menggantung di bawah notch.
            if let Some((ml, mt, mr, mb)) = mascot {
                let m = CreateRectRgn(ml, mt, mr, mb);
                CombineRgn(body, body, m, RGN_OR);
                free(m);
            }

            // Kepemilikan `body` pindah ke sistem — jangan dihapus.
            SetWindowRgn(h, body, BOOL::from(true));
        }
    }

    pub fn work_area() -> (i32, i32, i32, i32) {
        let mut rc = RECT::default();
        unsafe {
            let _ = SystemParametersInfoW(
                SPI_GETWORKAREA,
                0,
                Some(&mut rc as *mut RECT as *mut _),
                SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0),
            );
        }
        (rc.left, rc.top, rc.right, rc.bottom)
    }

    pub fn cursor_pos() -> Option<(i32, i32)> {
        let mut p = POINT::default();
        unsafe { GetCursorPos(&mut p).ok()? };
        Some((p.x, p.y))
    }
}
