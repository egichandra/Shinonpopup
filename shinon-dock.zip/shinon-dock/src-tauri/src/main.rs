// Tanpa jendela console di build release.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    shinon_dock_lib::run()
}
