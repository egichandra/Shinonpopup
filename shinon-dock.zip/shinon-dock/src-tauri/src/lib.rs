mod dock;
mod media;

use tauri::{
    menu::{Menu, MenuItem},
    tray::TrayIconBuilder,
    Emitter, Manager,
};
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut, ShortcutState};

pub fn run() {
    tauri::Builder::default()
        // Harus plugin pertama: mencegah dua dock berjalan bersamaan.
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            let _ = app.emit("dock://hotkey", ());
        }))
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(|app, _shortcut, event| {
                    if event.state() == ShortcutState::Pressed {
                        let _ = app.emit("dock://hotkey", ());
                    }
                })
                .build(),
        )
        .manage(dock::DockState::default())
        .setup(|app| {
            let win = app
                .get_webview_window("dock")
                .expect("window 'dock' tidak ditemukan di tauri.conf.json");

            dock::configure(&win)?;
            dock::start_hover_watch(app.handle().clone());
            media::start(app.handle().clone());

            // Ctrl + Alt + Space → munculkan / sembunyikan dock.
            app.global_shortcut()
                .register(Shortcut::new(Some(Modifiers::CONTROL | Modifiers::ALT), Code::Space))?;

            build_tray(app)?;
            win.show()?;
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            media::media_command,
            dock::set_pill_rect,
            dock::set_ghost,
        ])
        .run(tauri::generate_context!())
        .expect("gagal menjalankan Shinon Dock");
}

/// Buka CREDITS.txt (ikut terpasang di folder instalasi) dengan Notepad.
fn open_credits(app: &tauri::AppHandle) {
    use tauri::path::BaseDirectory;
    let Ok(path) = app.path().resolve("CREDITS.txt", BaseDirectory::Resource) else { return };
    #[cfg(windows)]
    let _ = std::process::Command::new("notepad.exe").arg(&path).spawn();
    #[cfg(not(windows))]
    let _ = path;
}

/// Tray icon = satu-satunya "pintu" aplikasi (tidak ada ikon di taskbar).
fn build_tray(app: &tauri::App) -> tauri::Result<()> {
    let toggle = MenuItem::with_id(app, "toggle", "Tampilkan / Sembunyikan  (Ctrl+Alt+Space)", true, None::<&str>)?;
    let reposition = MenuItem::with_id(app, "reposition", "Posisikan ulang", true, None::<&str>)?;
    let credits = MenuItem::with_id(app, "credits", "Tentang & Kredit…", true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", "Keluar", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&toggle, &reposition, &credits, &quit])?;

    let mut tray = TrayIconBuilder::with_id("main")
        .tooltip("Shinon Dock — by Shinon")
        .menu(&menu)
        .on_menu_event(|app, event| match event.id.as_ref() {
            "toggle" => {
                let _ = app.emit("dock://hotkey", ());
            }
            "reposition" => {
                if let Some(w) = app.get_webview_window("dock") {
                    let _ = dock::place_at_top(&w);
                }
            }
            "credits" => open_credits(app),
            "quit" => app.exit(0),
            _ => {}
        });

    if let Some(icon) = app.default_window_icon() {
        tray = tray.icon(icon.clone());
    }
    tray.build(app)?;
    Ok(())
}
