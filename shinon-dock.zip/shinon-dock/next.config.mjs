/** @type {import('next').NextConfig} */
const nextConfig = {
  // Tauri memuat file statis dari ./out — tidak ada server Node yang jalan di belakang.
  output: "export",
  images: { unoptimized: true },
  devIndicators: false,
  reactStrictMode: true,
};

export default nextConfig;
