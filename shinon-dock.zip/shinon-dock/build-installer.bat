@echo off
setlocal
title Shinon Dock - Build Installer
cd /d "%~dp0"

echo ==============================================
echo   Shinon Dock - Build Installer Windows
echo   Developer: Shinon (egichandra48@gmail.com)
echo ==============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js belum terpasang. Unduh di https://nodejs.org ^(versi 20 LTS^)
  pause & exit /b 1
)

where cargo >nul 2>nul
if errorlevel 1 (
  echo [!] Rust belum terpasang. Unduh di https://rustup.rs
  echo     Saat instalasi, pilih toolchain "stable-x86_64-pc-windows-msvc".
  echo     Butuh juga Visual Studio Build Tools 2022 - workload "Desktop development with C++".
  pause & exit /b 1
)

echo [1/2] Memasang dependensi...
call npm ci
if errorlevel 1 ( echo [!] npm ci gagal. & pause & exit /b 1 )

echo.
echo [2/2] Membangun aplikasi dan installer ^(build pertama bisa 5-10 menit^)...
call npm run release
if errorlevel 1 ( echo [!] Build gagal. Lihat pesan di atas. & pause & exit /b 1 )

echo.
echo Selesai! Installer ada di:
echo   src-tauri\target\release\bundle\nsis\
explorer "src-tauri\target\release\bundle\nsis"
pause
