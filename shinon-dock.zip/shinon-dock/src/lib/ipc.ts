import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";

/** true saat berjalan di dalam Tauri; false saat dibuka di browser biasa (mode desain). */
export const isTauri = (): boolean =>
  typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

export async function call<T = void>(cmd: string, args?: Record<string, unknown>): Promise<T | undefined> {
  if (!isTauri()) return undefined;
  try {
    return await invoke<T>(cmd, args);
  } catch (err) {
    console.warn(`[ipc] ${cmd} gagal`, err);
    return undefined;
  }
}

export async function on<T>(event: string, cb: (payload: T) => void): Promise<UnlistenFn> {
  if (!isTauri()) return () => {};
  return listen<T>(event, (e) => cb(e.payload));
}

/* ---------- Dock (window) ---------- */

export const dock = {
  setPillRect: (
    x: number, y: number, w: number, h: number, r: number, ear: number,
    mx = 0, my = 0, mw = 0, mh = 0,
  ) => call("set_pill_rect", { x, y, w, h, r, ear, mx, my, mw, mh }),
  setGhost: (ghost: boolean) => call("set_ghost", { ghost }),
};
