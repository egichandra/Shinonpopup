/** Cermin dari struct `MediaState` di src-tauri/src/media.rs */
export interface MediaState {
  hasSession: boolean;
  appId: string;
  title: string;
  artist: string;
  album: string;
  trackKey: string;
  isPlaying: boolean;
  positionMs: number;
  durationMs: number;
  updatedAtMs: number;
  canPrev: boolean;
  canNext: boolean;
  canToggle: boolean;
}

export interface Artwork {
  trackKey: string;
  dataUrl: string | null;
}

export type MediaCommand =
  | { type: "togglePlay" }
  | { type: "next" }
  | { type: "previous" }
  | { type: "seek"; positionMs: number }
  | { type: "refresh" };

export const EMPTY_MEDIA: MediaState = {
  hasSession: false,
  appId: "",
  title: "",
  artist: "",
  album: "",
  trackKey: "",
  isPlaying: false,
  positionMs: 0,
  durationMs: 0,
  updatedAtMs: 0,
  canPrev: false,
  canNext: false,
  canToggle: false,
};
