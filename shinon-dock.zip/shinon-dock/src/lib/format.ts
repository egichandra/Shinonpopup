export function formatTime(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) ms = 0;
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
}

const KNOWN_APPS: [string, string][] = [
  ["spotify", "Spotify"],
  ["msedge", "Edge"],
  ["chrome", "Chrome"],
  ["firefox", "Firefox"],
  ["zunemusic", "Media Player"],
  ["applemusic", "Apple Music"],
  ["youtube", "YouTube Music"],
  ["vlc", "VLC"],
  ["foobar", "foobar2000"],
  ["tidal", "TIDAL"],
  ["deezer", "Deezer"],
  ["musicbee", "MusicBee"],
];

/** "SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify" → "Spotify" */
export function appLabel(appId: string): string {
  if (!appId) return "";
  const low = appId.toLowerCase();
  for (const [key, label] of KNOWN_APPS) if (low.includes(key)) return label;
  const base = appId.split("!")[0].split("_")[0].replace(/\.exe$/i, "");
  return base.split(".").pop() || base;
}
