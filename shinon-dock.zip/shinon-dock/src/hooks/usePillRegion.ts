"use client";

import { useEffect, useRef, type RefObject } from "react";
import { dock, isTauri } from "@/lib/ipc";

/**
 * Melaporkan kotak notch ke Rust supaya window region (bentuk window di level OS)
 * selalu sama dengan pill. Hasilnya:
 *  - area di luar pill benar-benar tembus klik,
 *  - efek Acrylic hanya terlihat di dalam pill.
 * Saat animasi berjalan, laporan dikirim per-frame; di luar itu, diam total.
 */
export function usePillRegion(
  ref: RefObject<HTMLElement | null>,
  trigger: unknown,
  /** Elemen tambahan di luar notch (maskot yang menggantung) yang harus tetap terlihat. */
  extraRef?: RefObject<HTMLElement | null>,
  animMs = 900,
) {
  const last = useRef("");

  useEffect(() => {
    const el = ref.current;
    if (!el || !isTauri()) return;

    const report = () => {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      // Notch: sudut atas lurus, radius diambil dari sudut BAWAH.
      const radius = Math.min(parseFloat(cs.borderBottomLeftRadius) || 0, r.height);
      const ear = parseFloat(cs.getPropertyValue("--ear")) || 0;
      const x = extraRef?.current?.getBoundingClientRect();
      const m = x && x.width > 0 ? x : { x: 0, y: 0, width: 0, height: 0 };
      const key = [r.x, r.y, r.width, r.height, radius, ear, m.x, m.y, m.width, m.height]
        .map((v) => v.toFixed(1))
        .join("|");
      if (key === last.current) return;
      last.current = key;
      void dock.setPillRect(r.x, r.y, r.width, r.height, radius, ear, m.x, m.y, m.width, m.height);
    };

    let raf = 0;
    const until = performance.now() + animMs;
    const loop = () => {
      report();
      if (performance.now() < until) raf = requestAnimationFrame(loop);
    };
    loop();

    const ro = new ResizeObserver(report);
    ro.observe(el);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [ref, extraRef, trigger, animMs]);
}
