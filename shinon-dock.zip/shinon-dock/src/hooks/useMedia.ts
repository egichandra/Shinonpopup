"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { call, isTauri, on } from "@/lib/ipc";
import { EMPTY_MEDIA, type Artwork, type MediaCommand, type MediaState } from "@/lib/media-types";

/** Posisi lagu saat ini, diinterpolasi tanpa polling ke backend. */
export function currentPosition(m: MediaState, receivedAt: number, now = Date.now()): number {
  if (!m.isPlaying) return m.positionMs;
  // Sebagian app mengirim LastUpdatedTime = 0 atau aneh → pakai waktu event diterima.
  const anchor = m.updatedAtMs > 0 && m.updatedAtMs <= now + 1000 ? m.updatedAtMs : receivedAt;
  const pos = m.positionMs + Math.max(0, now - anchor);
  return m.durationMs > 0 ? Math.min(pos, m.durationMs) : pos;
}

const MOCK: MediaState = {
  ...EMPTY_MEDIA,
  hasSession: true,
  appId: "Spotify.exe",
  title: "Midnight Drive (Preview)",
  artist: "Mode Desain Browser",
  album: "Shinon Dock",
  trackKey: "mock",
  isPlaying: true,
  positionMs: 42_000,
  durationMs: 214_000,
  updatedAtMs: 0,
  canPrev: true,
  canNext: true,
  canToggle: true,
};

export function useMedia() {
  const [media, setMedia] = useState<MediaState>(EMPTY_MEDIA);
  const [artwork, setArtwork] = useState<string | null>(null);
  const [receivedAt, setReceivedAt] = useState(() => Date.now());
  const keyRef = useRef("");

  useEffect(() => {
    // Dibuka di browser biasa → tampilkan data contoh agar UI bisa didesain.
    if (!isTauri()) {
      setMedia({ ...MOCK, updatedAtMs: Date.now() });
      return;
    }

    let disposed = false;
    const offs: Array<() => void> = [];

    (async () => {
      offs.push(
        await on<MediaState>("media://update", (s) => {
          if (s.trackKey !== keyRef.current) {
            keyRef.current = s.trackKey;
            setArtwork(null);
          }
          setReceivedAt(Date.now());
          setMedia(s);
        }),
      );
      offs.push(
        await on<Artwork>("media://artwork", (a) => {
          if (a.trackKey === keyRef.current) setArtwork(a.dataUrl);
        }),
      );
      if (disposed) offs.forEach((off) => off());
      else void call("media_command", { cmd: { type: "refresh" } satisfies MediaCommand });
    })();

    return () => {
      disposed = true;
      offs.forEach((off) => off());
    };
  }, []);

  const control = useCallback(
    (cmd: MediaCommand) => {
      // Update optimistis supaya tombol terasa instan.
      if (cmd.type === "togglePlay") {
        const now = Date.now();
        setMedia((m) => ({
          ...m,
          isPlaying: !m.isPlaying,
          positionMs: currentPosition(m, receivedAt, now),
          updatedAtMs: now,
        }));
      }
      if (cmd.type === "seek") {
        setMedia((m) => ({ ...m, positionMs: cmd.positionMs, updatedAtMs: Date.now() }));
      }
      if (isTauri()) void call("media_command", { cmd });
    },
    [receivedAt],
  );

  return { media, artwork, receivedAt, control };
}

/** Tick ringan (default 500 ms) — hanya berjalan saat lagu diputar DAN UI terlihat. */
export function usePosition(media: MediaState, receivedAt: number, active: boolean, interval = 500) {
  const [pos, setPos] = useState(() => currentPosition(media, receivedAt));

  useEffect(() => {
    setPos(currentPosition(media, receivedAt));
    if (!active || !media.isPlaying) return;
    const id = window.setInterval(() => setPos(currentPosition(media, receivedAt)), interval);
    return () => window.clearInterval(id);
  }, [media, receivedAt, active, interval]);

  return pos;
}
