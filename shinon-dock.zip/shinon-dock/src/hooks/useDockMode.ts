"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { dock, isTauri, on } from "@/lib/ipc";

export type DockMode = "ghost" | "compact" | "expanded";

/** Berapa lama dock tetap compact setelah aktivitas berhenti sebelum jadi ghost. */
const IDLE_TO_GHOST_MS = 5000;
/** Jeda sebelum menyusut setelah kursor keluar dari pill. */
const LEAVE_DELAY_MS = 450;
/** Kalau dock dimunculkan oleh hover-zone tapi kursor tidak masuk ke pill. */
const PEEK_TIMEOUT_MS = 2200;

/**
 * State machine dock:
 *   ghost ──hover/hotkey──▶ expanded ──leave──▶ compact (jika ada aktivitas) / ghost
 *   ghost ──musik mulai──▶ compact ──hover──▶ expanded
 */
export function useDockMode(activity: boolean) {
  const [hovered, setHovered] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [lingering, setLingering] = useState(activity);

  const leaveTimer = useRef<number | undefined>(undefined);
  const peekTimer = useRef<number | undefined>(undefined);
  const insideRef = useRef(false);

  // Aktivitas berhenti → tetap compact sebentar, baru menghilang.
  useEffect(() => {
    if (activity) {
      setLingering(true);
      return;
    }
    const id = window.setTimeout(() => setLingering(false), IDLE_TO_GHOST_MS);
    return () => window.clearTimeout(id);
  }, [activity]);

  const mode: DockMode = pinned || hovered ? "expanded" : activity || lingering ? "compact" : "ghost";

  // Beri tahu Rust: ghost = click-through penuh + mulai pantau kursor.
  useEffect(() => {
    void dock.setGhost(mode === "ghost");
  }, [mode]);

  const onEnter = useCallback(() => {
    insideRef.current = true;
    window.clearTimeout(leaveTimer.current);
    window.clearTimeout(peekTimer.current);
    setHovered(true);
  }, []);

  const onLeave = useCallback(() => {
    insideRef.current = false;
    window.clearTimeout(leaveTimer.current);
    leaveTimer.current = window.setTimeout(() => {
      setHovered(false);
      setPinned(false);
    }, LEAVE_DELAY_MS);
  }, []);

  // Event dari Rust: kursor diam di zona bawah saat ghost, atau hotkey ditekan.
  useEffect(() => {
    const offs: Array<() => void> = [];
    let disposed = false;

    const peek = () => {
      setHovered(true);
      window.clearTimeout(peekTimer.current);
      peekTimer.current = window.setTimeout(() => {
        if (!insideRef.current) setHovered(false);
      }, PEEK_TIMEOUT_MS);
    };

    (async () => {
      offs.push(await on<boolean>("dock://hover", (inside) => inside && peek()));
      offs.push(await on("dock://hotkey", () => setPinned((p) => !p)));
      if (disposed) offs.forEach((off) => off());
    })();

    // Mode desain di browser: tekan Ctrl+Alt+Space juga.
    const onKey = (e: KeyboardEvent) => {
      if (!isTauri() && e.ctrlKey && e.altKey && e.code === "Space") setPinned((p) => !p);
    };
    window.addEventListener("keydown", onKey);

    return () => {
      disposed = true;
      offs.forEach((off) => off());
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(leaveTimer.current);
      window.clearTimeout(peekTimer.current);
    };
  }, []);

  return { mode, pinned, onEnter, onLeave };
}
