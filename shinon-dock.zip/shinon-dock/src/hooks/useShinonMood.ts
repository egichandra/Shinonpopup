"use client";

import { useEffect, useRef, useState } from "react";
import type { ShinonMood } from "@/components/mascot/Shinon";
import type { DockMode } from "./useDockMode";

/** Setelah sekian lama tanpa musik & tanpa interaksi, Shinon tertidur. */
const SLEEP_AFTER_MS = 30_000;
/** Durasi sapaan saat notch dibuka. */
const WAVE_MS = 1400;

/**
 * Menentukan suasana hati Shinon dari keadaan dock:
 *  - notch baru dibuka        → wave (menyapa), lalu…
 *  - musik diputar            → listen (mengangguk)
 *  - tidak ada apa-apa        → idle, lalu sleep setelah 30 detik
 *  - `alert` dipicu dari luar (mis. timer selesai)
 */
export function useShinonMood(mode: DockMode, playing: boolean, alert = false): ShinonMood {
  const [waving, setWaving] = useState(false);
  const [sleepy, setSleepy] = useState(false);
  const prevMode = useRef(mode);

  // Sapa setiap kali notch berubah menjadi expanded.
  useEffect(() => {
    if (mode === "expanded" && prevMode.current !== "expanded") {
      setWaving(true);
      const id = window.setTimeout(() => setWaving(false), WAVE_MS);
      prevMode.current = mode;
      return () => window.clearTimeout(id);
    }
    prevMode.current = mode;
  }, [mode]);

  // Hitung mundur tidur; direset oleh musik atau gerakan mouse.
  useEffect(() => {
    if (playing) {
      setSleepy(false);
      return;
    }
    let id = window.setTimeout(() => setSleepy(true), SLEEP_AFTER_MS);
    const wake = () => {
      setSleepy(false);
      window.clearTimeout(id);
      id = window.setTimeout(() => setSleepy(true), SLEEP_AFTER_MS);
    };
    window.addEventListener("mousemove", wake);
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("mousemove", wake);
    };
  }, [playing]);

  if (alert) return "alert";
  if (waving) return "wave";
  if (playing) return "listen";
  if (sleepy) return "sleep";
  return mode === "compact" ? "peek" : "idle";
}
