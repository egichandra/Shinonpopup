"use client";

import { useEffect, useState } from "react";

/** Ditampilkan saat dock dibuka tapi tidak ada media. Jam di-update tiap 15 detik saja. */
export function IdleCard() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 15_000);
    return () => window.clearInterval(id);
  }, []);

  const time = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  const date = now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="idle">
      <span className="clock">{time}</span>
      <span className="sub">{date}</span>
      <span className="hint">Tidak ada media yang diputar</span>
    </div>
  );
}
