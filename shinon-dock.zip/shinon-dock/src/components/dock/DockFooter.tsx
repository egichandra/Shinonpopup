import { LyricsIcon, NoteIcon, StashIcon, TimerIcon } from "@/components/icons/Icons";

const MODULES = [
  { id: "music", label: "Musik", Icon: NoteIcon, ready: true },
  { id: "lyrics", label: "Lirik", Icon: LyricsIcon, ready: false },
  { id: "timer", label: "Timer", Icon: TimerIcon, ready: false },
  { id: "stash", label: "Stash", Icon: StashIcon, ready: false },
] as const;

/**
 * Footer ala iOS: deretan modul seperti dock iOS + home indicator.
 * Home indicator yang sama adalah satu-satunya yang tersisa saat ghost mode,
 * jadi transisinya terasa "menyusut ke garis" seperti di iPhone.
 */
export function DockFooter({ active = "music" }: { active?: string }) {
  return (
    <footer className="dock-footer">
      <nav className="module-row">
        {MODULES.map(({ id, label, Icon, ready }) => (
          <button
            key={id}
            className="module-chip"
            data-active={id === active}
            disabled={!ready}
            title={ready ? label : `${label} — segera`}
          >
            <Icon width={14} height={14} />
            <span>{label}</span>
          </button>
        ))}
      </nav>
      <span className="home-indicator" />
    </footer>
  );
}
