"use client";

import { useRef, type PointerEvent, type ReactNode } from "react";
import { NextIcon, PauseIcon, PlayIcon, PrevIcon } from "@/components/icons/Icons";
import { appLabel, formatTime } from "@/lib/format";
import type { MediaCommand, MediaState } from "@/lib/media-types";
import { Artwork } from "./Artwork";
import { Equalizer } from "./Equalizer";

interface Props {
  media: MediaState;
  artwork: string | null;
  position: number;
  control: (cmd: MediaCommand) => void;
  /** Elemen di kanan compact (default: equalizer; di dock: maskot Shinon). */
  trailing?: ReactNode;
}

/* ------------------------------------------------------------------ */
/* Compact: satu baris di dalam pill kecil                             */
/* ------------------------------------------------------------------ */
export function MusicCompact({ media, artwork, control, trailing }: Props) {
  return (
    <div className="compact">
      <Artwork src={artwork} size={30} radius={9} />
      <div className="compact-text">
        <span className="title">{media.title || "Tanpa judul"}</span>
        {media.artist && <span className="sub"> · {media.artist}</span>}
      </div>
      {trailing ?? <Equalizer playing={media.isPlaying} />}
      <button
        className="icon-btn round"
        aria-label={media.isPlaying ? "Pause" : "Play"}
        disabled={!media.canToggle}
        onClick={() => control({ type: "togglePlay" })}
      >
        {media.isPlaying ? <PauseIcon width={14} height={14} /> : <PlayIcon width={14} height={14} />}
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Expanded: kartu penuh dengan progress + kontrol                     */
/* ------------------------------------------------------------------ */
export function MusicExpanded({ media, artwork, position, control }: Props) {
  const barRef = useRef<HTMLDivElement>(null);
  const progress = media.durationMs > 0 ? Math.min(1, position / media.durationMs) : 0;

  const seek = (e: PointerEvent<HTMLDivElement>) => {
    const el = barRef.current;
    if (!el || media.durationMs <= 0) return;
    const r = el.getBoundingClientRect();
    const f = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    control({ type: "seek", positionMs: Math.round(f * media.durationMs) });
  };

  return (
    <div className="expanded">
      <div className="now-row">
        <Artwork src={artwork} size={56} radius={14} />
        <div className="now-text">
          <span className="title lg">{media.title || "Tanpa judul"}</span>
          <span className="sub">{media.artist || media.album || "—"}</span>
          <span className="source">{appLabel(media.appId)}</span>
        </div>
        <Equalizer playing={media.isPlaying} size={18} />
      </div>

      <div className="progress-row">
        <span className="time">{formatTime(position)}</span>
        <div className="bar" ref={barRef} onPointerDown={seek} role="slider" aria-valuenow={Math.round(progress * 100)}>
          <div className="bar-fill" style={{ transform: `scaleX(${progress})` }} />
        </div>
        <span className="time">-{formatTime(Math.max(0, media.durationMs - position))}</span>
      </div>

      <div className="controls">
        <button className="icon-btn" aria-label="Sebelumnya" disabled={!media.canPrev} onClick={() => control({ type: "previous" })}>
          <PrevIcon width={22} height={22} />
        </button>
        <button
          className="icon-btn main"
          aria-label={media.isPlaying ? "Pause" : "Play"}
          disabled={!media.canToggle}
          onClick={() => control({ type: "togglePlay" })}
        >
          {media.isPlaying ? <PauseIcon width={26} height={26} /> : <PlayIcon width={26} height={26} />}
        </button>
        <button className="icon-btn" aria-label="Berikutnya" disabled={!media.canNext} onClick={() => control({ type: "next" })}>
          <NextIcon width={22} height={22} />
        </button>
      </div>
    </div>
  );
}
