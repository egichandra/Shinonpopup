import { NoteIcon } from "@/components/icons/Icons";

export function Artwork({ src, size, radius }: { src: string | null; size: number; radius: number }) {
  return (
    <span className="art" style={{ width: size, height: size, borderRadius: radius }}>
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" draggable={false} />
      ) : (
        <NoteIcon width={size * 0.46} height={size * 0.46} />
      )}
    </span>
  );
}
