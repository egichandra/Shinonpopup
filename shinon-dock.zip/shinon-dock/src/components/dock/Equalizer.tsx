/** 4 batang animasi (transform-only → dikerjakan GPU, ~0% CPU). Berhenti saat pause. */
export function Equalizer({ playing, size = 14 }: { playing: boolean; size?: number }) {
  return (
    <span className="eq" data-playing={playing} style={{ height: size, width: size }} aria-hidden>
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}
