"use client";

import { useEffect, useRef } from "react";
import { Shinon } from "@/components/mascot/Shinon";
import { useDockMode } from "@/hooks/useDockMode";
import { useMedia, usePosition } from "@/hooks/useMedia";
import { usePillRegion } from "@/hooks/usePillRegion";
import { useShinonMood } from "@/hooks/useShinonMood";
import { isTauri } from "@/lib/ipc";
import { DockFooter } from "./DockFooter";
import { IdleCard } from "./IdleCard";
import { MusicCompact, MusicExpanded } from "./MusicModule";
import { NotchHeader } from "./NotchHeader";

export function Dock() {
  const { media, artwork, receivedAt, control } = useMedia();

  // "Aktivitas" = sesuatu yang layak membuat dock terlihat.
  // Nanti: || timer.running || stash.count > 0
  const activity = media.hasSession && media.isPlaying;

  const { mode, onEnter, onLeave } = useDockMode(activity);
  const position = usePosition(media, receivedAt, mode === "expanded");
  const mood = useShinonMood(mode, media.hasSession && media.isPlaying);

  const pillRef = useRef<HTMLDivElement>(null);
  const hangRef = useRef<HTMLDivElement>(null);
  usePillRegion(pillRef, mode, hangRef);

  useEffect(() => {
    document.documentElement.dataset.host = isTauri() ? "tauri" : "browser";
  }, []);

  return (
    <main className="stage">
      <div
        ref={pillRef}
        className="pill"
        data-mode={mode}
        onMouseEnter={onEnter}
        onMouseLeave={onLeave}
      >
        {mode === "compact" && (
          <div className="layer" key="compact">
            {media.hasSession ? (
              <MusicCompact
                media={media}
                artwork={artwork}
                position={position}
                control={control}
                trailing={<Shinon mood={mood} size={32} />}
              />
            ) : (
              <div className="compact compact-solo">
                <Shinon mood={mood} size={28} />
                <span className="sub">Shinon</span>
              </div>
            )}
          </div>
        )}

        {mode === "expanded" && (
          <div className="layer" key="expanded">
            <NotchHeader />
            {media.hasSession ? (
              <MusicExpanded media={media} artwork={artwork} position={position} control={control} />
            ) : (
              <IdleCard />
            )}
            <DockFooter active="music" />
          </div>
        )}

        {/* Shinon menggantung di tepi bawah notch saat terbuka */}
        {mode === "expanded" && (
          <div className="mascot-hang" ref={hangRef} key="hang">
            <Shinon mood={mood} size={54} followCursor />
          </div>
        )}
      </div>
    </main>
  );
}
