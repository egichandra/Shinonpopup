"use client";

import { useEffect, useState } from "react";

/** Baris status di bagian atas notch: tanggal + jam. Update tiap 15 detik. */
export function NotchHeader() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 15_000);
    return () => window.clearInterval(id);
  }, []);

  const date = now.toLocaleDateString("id-ID", { weekday: "short", day: "numeric", month: "short" });
  const time = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });

  return (
    <header className="notch-header">
      <span className="status-dot" aria-hidden />
      <span>{date}</span>
      <strong>{time}</strong>
    </header>
  );
}
