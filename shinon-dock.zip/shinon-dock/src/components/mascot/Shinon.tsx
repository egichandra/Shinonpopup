"use client";

import { useEffect, useRef, type CSSProperties } from "react";

/**
 * Shinon — maskot Shinon Dock: anak ayam robot kuning yang chubby.
 * Antena di kepala berujung tunas daun LED (berkedip/berdenyut sesuai mood),
 * badan bulat dengan sambungan panel & baut, paruh berengsel, kaki piston.
 *
 * Semua gerakan = CSS transform/opacity pada SVG → digarap GPU, ~0% CPU.
 */
export type ShinonMood = "idle" | "peek" | "listen" | "sleep" | "wave" | "alert";

interface Props {
  mood: ShinonMood;
  size?: number;
  /** Warna LED daun & cincin mata. Default: hijau daun. */
  accent?: string;
  /** Mata mengikuti kursor (hanya saat dock aktif). */
  followCursor?: boolean;
  className?: string;
}

export function Shinon({ mood, size = 44, accent = "#5fe39a", followCursor = false, className }: Props) {
  const ref = useRef<HTMLSpanElement>(null);

  // Mata melirik ke arah kursor — ditulis langsung ke CSS variable, tanpa re-render.
  useEffect(() => {
    const el = ref.current;
    if (!el || !followCursor) return;
    let raf = 0;
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect();
        const dx = (e.clientX - (r.left + r.width / 2)) / 160;
        const dy = (e.clientY - (r.top + r.height / 2)) / 160;
        el.style.setProperty("--look-x", Math.max(-1, Math.min(1, dx)).toFixed(2));
        el.style.setProperty("--look-y", Math.max(-1, Math.min(1, dy)).toFixed(2));
      });
    };
    window.addEventListener("mousemove", onMove);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
    };
  }, [followCursor]);

  return (
    <span
      ref={ref}
      className={`shinon ${className ?? ""}`}
      data-mood={mood}
      style={{ "--s": `${size}px`, "--spark": accent } as CSSProperties}
      aria-hidden
    >
      <svg viewBox="0 0 64 64" width={size} height={size}>
        <defs>
          <radialGradient id="sh-body-grad" cx="38%" cy="30%" r="75%">
            <stop offset="0" stopColor="#fff3a8" />
            <stop offset="0.45" stopColor="#ffd93d" />
            <stop offset="1" stopColor="#f4b400" />
          </radialGradient>
        </defs>

        <g className="sh-body">
          {/* kaki piston */}
          <g className="sh-feet">
            <path className="sh-leg" d="M26 56v4.6M38 56v4.6" />
            <ellipse className="sh-foot" cx="25.4" cy="61.6" rx="3.2" ry="1.5" />
            <ellipse className="sh-foot" cx="38.6" cy="61.6" rx="3.2" ry="1.5" />
          </g>

          {/* sayap kecil */}
          <path className="sh-wing sh-wing-l" d="M9.5 37c-5 .6-7.6 4.6-6.8 8.2 3.2 1 6.6-.8 8.6-3.2Z" />
          <path className="sh-wing sh-wing-r" d="M54.5 37c5 .6 7.6 4.6 6.8 8.2-3.2 1-6.6-.8-8.6-3.2Z" />

          {/* antena + daun LED */}
          <g className="sh-antenna">
            <path className="sh-rod" d="M32 19V9.5" />
            <g className="sh-leaf">
              <path d="M32 9.5c-1.2-4.2-5.2-6.4-9.4-5.4 1 4.2 5 6.6 9.4 5.4Z" />
              <path d="M32 9.5c1.2-4.2 5.2-6.4 9.4-5.4-1 4.2-5 6.6-9.4 5.4Z" />
              <circle cx="32" cy="9.5" r="1.7" />
            </g>
          </g>

          {/* badan chubby */}
          <path
            className="sh-blob"
            d="M32 17.5c14.2 0 24.5 10 24.5 23.2 0 11-9.2 17.3-24.5 17.3S7.5 51.7 7.5 40.7C7.5 27.5 17.8 17.5 32 17.5Z"
          />
          <rect className="sh-collar" x="28.6" y="16.4" width="6.8" height="3.2" rx="1.6" />
          <ellipse className="sh-gloss" cx="23" cy="25.5" rx="6.5" ry="3" transform="rotate(-22 23 25.5)" />
          <path className="sh-seam" d="M17 48.5c8.6 4 21.4 4 30 0" />
          <circle className="sh-rivet" cx="12.6" cy="40" r="1" />
          <circle className="sh-rivet" cx="51.4" cy="40" r="1" />

          {/* mata layar */}
          <g className="sh-eyes">
            <g className="sh-eye-open">
              <circle className="sh-eye" cx="23.5" cy="34.5" r="4.8" />
              <circle className="sh-eye" cx="40.5" cy="34.5" r="4.8" />
              <circle className="sh-ring" cx="23.5" cy="34.5" r="3.1" />
              <circle className="sh-ring" cx="40.5" cy="34.5" r="3.1" />
              <circle className="sh-shine" cx="25.2" cy="32.6" r="1.5" />
              <circle className="sh-shine" cx="42.2" cy="32.6" r="1.5" />
              <circle className="sh-shine sm" cx="22.2" cy="36.4" r="0.7" />
              <circle className="sh-shine sm" cx="39.2" cy="36.4" r="0.7" />
            </g>
            <path className="sh-eye-happy" d="M19.2 36q4.3-5.4 8.6 0M36.2 36q4.3-5.4 8.6 0" />
            <path className="sh-eye-closed" d="M19.2 35q4.3 3.4 8.6 0M36.2 35q4.3 3.4 8.6 0" />
          </g>

          {/* pipi */}
          <ellipse className="sh-blush" cx="15.8" cy="42.2" rx="3.4" ry="2" />
          <ellipse className="sh-blush" cx="48.2" cy="42.2" rx="3.4" ry="2" />

          {/* paruh berengsel */}
          <path className="sh-jaw" d="M29.4 43.6h5.2l-2.6 3.4Z" />
          <path
            className="sh-beak"
            d="M27.6 39.6h8.8c1.1 0 1.6 1.2.9 2l-4 3.8c-.7.6-1.9.6-2.6 0l-4-3.8c-.7-.8-.2-2 .9-2Z"
          />
          <path className="sh-beak-seam" d="M28.6 41.6h6.8" />
        </g>

        {/* z z — saat tidur */}
        <text className="sh-z" x="52" y="20">z</text>
        <text className="sh-z sh-z2" x="58" y="12">z</text>
      </svg>
    </span>
  );
}
