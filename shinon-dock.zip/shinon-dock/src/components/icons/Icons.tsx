import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;
const base = (p: P) => ({ width: 18, height: 18, viewBox: "0 0 24 24", "aria-hidden": true, ...p });

export const PlayIcon = (p: P) => (
  <svg {...base(p)} fill="currentColor">
    <path d="M7 4.8v14.4c0 .9 1 1.4 1.7.9l10.6-7.2c.6-.4.6-1.4 0-1.8L8.7 3.9C8 3.4 7 3.9 7 4.8Z" />
  </svg>
);

export const PauseIcon = (p: P) => (
  <svg {...base(p)} fill="currentColor">
    <rect x="6" y="4" width="4.2" height="16" rx="1.3" />
    <rect x="13.8" y="4" width="4.2" height="16" rx="1.3" />
  </svg>
);

export const NextIcon = (p: P) => (
  <svg {...base(p)} fill="currentColor">
    <path d="M3.5 6.2v11.6c0 .8.9 1.2 1.5.8l8-5.8c.5-.4.5-1.2 0-1.6l-8-5.8c-.6-.4-1.5 0-1.5.8Z" />
    <path d="M12 6.2v11.6c0 .8.9 1.2 1.5.8l8-5.8c.5-.4.5-1.2 0-1.6l-8-5.8c-.6-.4-1.5 0-1.5.8Z" />
  </svg>
);

export const PrevIcon = (p: P) => (
  <svg {...base(p)} fill="currentColor" style={{ transform: "scaleX(-1)", ...p.style }}>
    <path d="M3.5 6.2v11.6c0 .8.9 1.2 1.5.8l8-5.8c.5-.4.5-1.2 0-1.6l-8-5.8c-.6-.4-1.5 0-1.5.8Z" />
    <path d="M12 6.2v11.6c0 .8.9 1.2 1.5.8l8-5.8c.5-.4.5-1.2 0-1.6l-8-5.8c-.6-.4-1.5 0-1.5.8Z" />
  </svg>
);

export const NoteIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 18V5l11-2v13" />
    <circle cx="6.5" cy="18" r="2.5" />
    <circle cx="17.5" cy="16" r="2.5" />
  </svg>
);

export const LyricsIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
    <path d="M4 7h16M4 12h11M4 17h7" />
  </svg>
);

export const TimerIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
    <circle cx="12" cy="13.5" r="7.5" />
    <path d="M12 9.5v4l2.5 1.5M9.5 2.5h5" />
  </svg>
);

export const StashIcon = (p: P) => (
  <svg {...base(p)} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 13.5 6.2 5.6A1.6 1.6 0 0 1 7.7 4.5h8.6a1.6 1.6 0 0 1 1.5 1.1L20 13.5" />
    <path d="M4 13.5v4.4c0 .9.7 1.6 1.6 1.6h12.8c.9 0 1.6-.7 1.6-1.6v-4.4h-4.6l-1.2 2.2h-4.4L8.6 13.5Z" />
  </svg>
);
