import { Dock } from "@/components/dock/Dock";

export default function Page() {
  return <Dock />;
}
