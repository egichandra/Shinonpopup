import type { Metadata, Viewport } from "next";
import "./globals.css";
import "@/components/mascot/shinon.css";

export const metadata: Metadata = {
  title: "Shinon Dock",
};

export const viewport: Viewport = {
  colorScheme: "dark",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
