# Shinon Dock

Asisten layar untuk Windows berbentuk **notch (poni)** yang menggantung dari tepi atas layar.
Stack: **Tauri v2 (Rust) + Next.js 15 (static export)** — memakai WebView2 bawaan Windows,
bukan Chromium sendiri seperti Electron.

## Struktur proyek

```
shinon-dock/
├─ build-installer.bat     # build installer .exe sekali klik (Windows)
├─ .github/workflows/build-windows.yml   # build installer otomatis di GitHub
├─ package.json            # Next.js + Tauri CLI
├─ next.config.mjs         # output: "export" → ./out (tanpa server Node)
├─ src/
│  ├─ app/
│  │  ├─ layout.tsx
│  │  ├─ page.tsx
│  │  └─ globals.css       # glass, morph pill, footer ala iOS
│  ├─ components/
│  │  ├─ dock/
│  │  │  ├─ Dock.tsx          # root: memilih konten per mode
│  │  │  ├─ MusicModule.tsx   # MusicCompact + MusicExpanded
│  │  │  ├─ DockFooter.tsx    # module row + home indicator (iOS)
│  │  │  ├─ IdleCard.tsx
│  │  │  ├─ Artwork.tsx
│  │  │  └─ Equalizer.tsx
│  │  ├─ mascot/
│  │  │  ├─ Shinon.tsx        # maskot orisinal (SVG) + mata mengikuti kursor
│  │  │  └─ shinon.css        # motion: idle · peek · listen · sleep · wave · alert
│  │  └─ icons/Icons.tsx
│  ├─ hooks/
│  │  ├─ useMedia.ts        # event SMTC + interpolasi posisi
│  │  ├─ useDockMode.ts     # state machine ghost/compact/expanded
│  │  ├─ useShinonMood.ts   # suasana hati maskot dari keadaan dock & musik
│  │  └─ usePillRegion.ts   # sinkron bentuk pill → window region OS
│  └─ lib/
│     ├─ ipc.ts             # wrapper invoke/listen (aman di browser)
│     ├─ media-types.ts
│     └─ format.ts
└─ src-tauri/
   ├─ tauri.conf.json      # window transparan, frameless, always-on-top, acrylic
   ├─ Cargo.toml
   ├─ CREDITS.txt         # ikut terpasang, dibuka via tray / Start Menu
   ├─ windows/hooks.nsh   # hook installer: pintasan Kredit di Start Menu
   ├─ capabilities/default.json
   ├─ icons/
   └─ src/
      ├─ main.rs
      ├─ lib.rs            # plugin, hotkey, tray, setup
      ├─ dock.rs           # posisi di atas taskbar, region, ghost, hover-watch
      └─ media.rs          # Music Controller via Windows SMTC

# Fase berikutnya (belum dibuat):
#   src-tauri/src/lyrics.rs   + src/components/dock/LyricsModule.tsx  (LRCLIB, sinkron dari positionMs)
#   src-tauri/src/timer.rs    + src/components/dock/TimerModule.tsx   (timer di Rust, UI hanya render)
#   src-tauri/src/stash.rs    + src/components/dock/StashModule.tsx   (drag-in via onDragDropEvent, drag-out via plugin drag)
```

## Menjalankan

Prasyarat (Windows 10 1809+ / Windows 11):
- Node.js 20+
- Rust stable (`rustup default stable-msvc`)
- Visual Studio Build Tools 2022 → workload **Desktop development with C++**
- WebView2 Runtime (sudah ada di Windows 11)

```bash
npm install
npm run app        # = tauri dev (Next dev server + jendela dock)
npm run release    # installer NSIS di src-tauri/target/release/bundle/nsis
```

`npm run dev` saja → buka http://localhost:3000 di browser untuk mendesain UI dengan data contoh
(hover pill untuk expand, Ctrl+Alt+Space untuk pin).

## Membuat installer Windows (.exe)

**Opsi A — di PC Windows (sekali klik)**
1. Pasang Node.js 20 LTS, Rust (`rustup`, toolchain *stable-msvc*), dan Visual Studio Build Tools 2022
   (workload *Desktop development with C++*).
2. Klik dua kali `build-installer.bat`.
3. Installer muncul di `src-tauri\target\release\bundle\nsis\Shinon Dock_0.1.0_x64-setup.exe`.

**Opsi B — otomatis lewat GitHub Actions (tanpa install apa pun)**
1. Upload folder ini ke repository GitHub.
2. Tab **Actions → Build Windows Installer → Run workflow**.
3. Setelah ±10 menit, unduh installer dari bagian **Artifacts**.
   Untuk rilis: `git tag v0.1.0 && git push origin v0.1.0` → installer dilampirkan ke GitHub Release (draft).

Installer (NSIS) memasang per-user tanpa butuh admin, membuat folder Start Menu "Shinon Dock"
berisi aplikasi dan pintasan **Kredit** (CREDITS.txt di Notepad), serta mengunduh WebView2
otomatis bila belum ada.

## Cara kerjanya

| Perilaku | Implementasi |
|---|---|
| Transparan, frameless, always-on-top | `tauri.conf.json`: `transparent`, `decorations:false`, `alwaysOnTop`, `skipTaskbar` |
| Bentuk notch | **Window region** (`SetWindowRgn`) = round-rect dengan sudut atas lurus + dua telinga cekung (`CombineRgn`), sama persis dengan CSS `.pill::before/::after` |
| Click-through di luar notch | Otomatis, karena di luar region window "tidak ada" bagi OS |
| Ghost mode | Notch menyusut jadi garis hitam tipis di tepi atas; `set_ignore_cursor_events(true)` → 100% tembus klik |
| Muncul saat hover (ketika ghost) | Thread Rust memanggil `GetCursorPos` tiap 120 ms; kursor diam ±240 ms di strip 24 px tepi atas layar → `dock://hover` |
| Hotkey | `Ctrl+Alt+Space` (global shortcut) → pin/unpin dock |
| Tidak mencuri fokus | `WS_EX_NOACTIVATE` + `WS_EX_TOOLWINDOW` (tidak muncul di Alt+Tab) |
| Berjalan di latar | Tidak ada ikon taskbar; kontrol lewat tray icon. Single-instance. |

### Music Controller (SMTC)
`media.rs` memakai `GlobalSystemMediaTransportControlsSessionManager`:
- berlangganan `CurrentSessionChanged`, `MediaPropertiesChanged`, `PlaybackInfoChanged`,
  `TimelinePropertiesChanged` — **tidak ada polling**;
- event beruntun digabung (debounce) sebelum state dibaca;
- cover art dikirim sebagai data-URL lewat event terpisah, hanya saat lagu berganti;
- posisi lagu diinterpolasi di frontend (`positionMs + (now − updatedAtMs)`), tick 500 ms
  hanya saat dock terbuka.

Bekerja dengan semua pemutar yang terdaftar ke SMTC: Spotify, Media Player, browser (YouTube,
YouTube Music, SoundCloud), VLC 4, foobar2000 (dengan komponen SMTC), dll.

## Tips agar tetap ringan
- Release profile sudah `opt-level="s"`, LTO, strip → binary ±3–5 MB.
- `additionalBrowserArgs` mematikan fitur WebView2 yang tidak dipakai (translate, sync, dll).
- Saat ghost: tidak ada interval JS yang jalan, equalizer di-pause, hanya 1 thread Rust tidur.
- Perkiraan RAM: ±40–70 MB (mayoritas proses WebView2). Jika butuh <20 MB, alternatifnya
  WinUI 3/C# murni, dengan konsekuensi UI tidak bisa memakai Next.js.

## Catatan & batasan yang diketahui
- Posisi memakai work area **monitor utama**; pakai menu tray "Posisikan ulang" setelah ganti
  resolusi/monitor.
- Tepi window region tidak anti-aliased (sifat GDI). Pada DPI 125%+ hampir tidak terlihat.
- Efek Acrylic dimatikan untuk gaya notch (hitam pekat menyatu dengan bezel, dan lebih ringan).
- Bayangan CSS di bawah notch terpotong oleh region; itu disengaja agar area sekitar tetap tembus klik.
- Kode Win32/WinRT ditulis untuk crate `windows` 0.58; jangan naikkan versinya tanpa
  menyesuaikan tanda tangan `TypedEventHandler`.

## Maskot Shinon

Anak ayam robot kuning yang chubby: antena bertunas daun LED, mata layar yang mengikuti kursor, paruh berengsel, sayap kecil, dan kaki piston. Saat expanded ia menggantung dari notch lewat antenanya.

| Mood | Kapan |
|---|---|
| `peek` | Compact tanpa musik — menyembul dari dalam notch |
| `wave` | 1,4 detik setiap kali notch dibuka — mengepak sayap |
| `listen` | Musik diputar — goyang kepala, paruh bercicit, LED daun berdenyut, mata "^ ^" |
| `idle` | Tidak ada aktivitas — melayang, berkedip, mata melirik kursor |
| `sleep` | 30 detik tanpa musik & tanpa gerakan mouse |
| `alert` | Dipicu modul lain (timer selesai, file masuk Stash) |

Saat expanded, Shinon menggantung di tepi bawah notch; kotaknya ikut dimasukkan ke window
region (`set_pill_rect` parameter `mx,my,mw,mh`) agar tidak terpotong.
Warna LED daun bisa diganti lewat prop `accent` (mis. diambil dari warna sampul lagu).

## Kredit

Developer: **Shinon** · egichandra48@gmail.com · https://www.linkedin.com/in/chandraegi/

- `src-tauri/CREDITS.txt` ikut terpasang di folder instalasi (mis. `C:\Program Files\Shinon Dock\CREDITS.txt`)
  dan bisa dibuka di Notepad lewat menu tray **Tentang & Kredit…**.
- Nama publisher, copyright, dan deskripsi installer diatur di `tauri.conf.json → bundle`
  (terlihat di Settings → Apps dan di properti file `.exe`).
